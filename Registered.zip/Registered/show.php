
 <html>
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

 </head>
 <body>
 <?php include 'conf.php';
         $idx=$_GET['id'];
     	$sql = "SELECT * FROM data WHERE id=$idx";
		$result = $conn->query($sql);
       $row=$result->fetch_assoc();
?>
<nav class="nav-wrapper white">
    <div class="container">
      <a href="#" class="brand-logo black-text"><?php echo $row['title'] ;?>
      </a>
      <a href="#" class="sidenav-trigger" data-target="mobile-links">
        <i class="material-icons black-text">menu</i>
        </i>
      </a>
    </div>
  </nav>
  <ul class="sidenav" id="mobile-links">
    <li><a href="rankings.php"><h5>Ranking</h5></a></li>
    <li><a href="primo1.php"><h5>Blogs</h5></a></li>
    <li><a href="news.php"><h5>News</h5></a></li>
    <li><a href="about-us.php"><h5>About-Us</h5></a></li>
  </ul>
  






  
   
<script src="https://code.jquery.com/jquery-3.6.0.min.js">
</script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js">
 </script>
   <script>
    $(document).ready(function(){
     $('.sidenav').sidenav();
    })
  </script>
 </body>
 </html>