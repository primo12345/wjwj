<html>
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <h2>Rankings</h2>
      <ul class="collection with-header">
        <li class="collection-header"><h4>Pound For Pound</h4></li>
     
        <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
      
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
     
      </ul>
    </div>
    
    
        <div class="container">
      
      <ul class="collection with-header">
        <li class="collection-header"><h4>HW Rankings</h4></li>
     
        <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
      
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
     
      </ul>
    </div>
    
    
        <div class="container">
      
      <ul class="collection with-header">
        <li class="collection-header"><h4>LHW Rankings</h4></li>
     
        <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
      
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
     
      </ul>
    </div>
    
    
        <div class="container">
      
      <ul class="collection with-header">
        <li class="collection-header"><h4>LHW Rankings</h4></li>
     
        <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
      
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
     
      </ul>
    </div>
    
    
    
        <div class="container">
    
      <ul class="collection with-header">
        <li class="collection-header"><h4>MW Rankings</h4></li>
     
        <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
        
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
        
        
         <li class="collection-item avatar">
             <i class="material-icons circle blue">person</i>
        <span class="title"><h5>Jon Jones</h5></span>
        <p class="grey-text">LHW Goat</p>
      
        <a href="" class="secondary-content">
        <i class="material-icons blue-text">email</i>
        </a>
        </li>
     
      </ul>
    </div>
  </body>
</html>