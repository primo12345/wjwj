<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nav</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     
  <style>
    
    header {
      background : url("img/C2.jpg");
      background-size: cover;
      background-position: center;
      min-height:1000px;
      
    }
    @media screen and (max-width:670px){
      header {
        min-height:500px;
      }
    }
  </style>
</head>

<body>
  
  <!--Nav-->
  <nav class="nav-wrapper white">
    <div class="container">
      <a href="#" class="brand-logo black-text">UFC</a>
      <a href="#" class="sidenav-trigger" data-target="mobile-links">
        <i class="material-icons black-text">menu</i></i>
      </a>
    </div>
  </nav>
  <ul class="sidenav" id="mobile-links">
    <li><a href="index.php"><h5>Home</h5></a></li>
    <li><a href=""><h5>News</h5></a></li>
  
    <li><a href="Admin.php"><h5>Add</h5></a></li>
      <li><a href="index.php"><h5>Log-Out</h5></a></li>
  </ul>
  
  <header>
  </header>
  <div class="center-align white"><h3>WATCH <br>EMBEDDED</h3>
    <a href="https://youtu.be/TDcG0a-d358"
   class="white waves-effect waves-light btn-large black-text">WATCH</a>
  </div>
  
  
      


 
        <?php include "config.php";
            try {   
                    
               $stmt = $db->query('SELECT id, title, subtitle, page FROM data ORDER BY id DESC');

                while($row = $stmt->fetch()){
                ?>
                    
           <div class="container">
               <div class="row">
              <div class="col s12 16">
                 <div class="card">
              <div class="card-content">
               <span class="card-title">
                      <?php echo '<p>'.$row['title'].'</p>'; ?>
               </span>
              <p>
                 <?php echo '<p>'.$row['subtitle'].'</p>'; ?>
            </p>
          </div>
             <div class="card-action">
             
           
       
           <a href="newfile.php?id=<?php echo $row['id'] ?>">VIEW</a>
             </div>
       
        </div>
      </div>
    </div>
  </div>
             <?php   }

            } catch(PDOException $e) {
                echo $e->getMessage();
            }
        ?>

        
</div>

</div>

  
  
   
  

  





 
  

   <footer class="page-footer grey darken-3">
   <div class="container">
     <div class="row">
       <div class="col s12 l6">
       <h5>Join Now</h5>
     <p>The Ultimate Fighting Championship is an American mixed martial arts promotion company based in Las Vegas,
      Nevada, which is owned and operated by Zuffa, LLC</p>
       </div>
       <div class="col s12 l6">
        <h5>Connect</h5>  
          <ul>
            <li><a href="#" class="grey-text text-lighten-3">Email</a></li>
            <li><a href="Instagram app · Installed
Web results
Conor McGregor Official (@thenotoriousmma) • Instagram ..."class="grey-text text-lighten-3">Instagram</a></li>
            <li><a href="https://instagram.com/thenotoriousmma?utm_medium=copy_link" class="grey-text text-lighten-3">Twitter</a></li>
          </ul>
       </div>
     </div>
   </div>
 </footer>
  
  
  
  
      
    
  
  
  
  
  
  
  
  
      
    
  
  
  
  
  
   
 
 
<script src="https://code.jquery.com/jquery-3.6.0.min.js">
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js">
</script>

<script>
  $(document).ready(function(){
     $('.sidenav').sidenav();
  })
</script>
</body>
</html>
  