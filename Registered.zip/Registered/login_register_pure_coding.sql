-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 13, 2021 at 08:14 AM
-- Server version: 5.6.38
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_register_pure_coding`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `id` int(11) NOT NULL,
  `title` longtext NOT NULL,
  `subtitle` longtext NOT NULL,
  `page` longtext NOT NULL,
  `footer` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`id`, `title`, `subtitle`, `page`, `footer`) VALUES
(28, 'OLYMPIC GOLD MEDALIST GABLE STEVESON', 'The 21-year-old freestyle wrestler and 2021 NCAA heavyweight champion for the University of Minnesota made global headlines when he defeated three-time World Champion Geno Petriashvili of Georgia to grab the Olympic gold ', 'Since then, the combat sports world has been in the palm of Steveson’s hand.\r\n\r\nThere’s wild speculation as to what could be next for Steveson, whether it be the NFL, WWE, or perhaps the UFC.\r\n\r\nOn Monday, the Olympic gold medalist sent shockwaves of speculation through social media when he offered a friendly wave to the president of the UFC, Dana White.\r\n\r\n previously stated, Steveson is only 21-years-old. If the freestyle wrestling sensation decided to try his hand in the UFC at such a young age, there is an argument to be made that he could be one of the most intriguing MMA prospects of all-time.', 'Nonetheless, Steveson’s signal to White is an encouraging sign to those who are eager to see him compete in Mixed Martial Arts one day.'),
(29, 'ALEXANDER VOLKANOVSKI AND BRIAN ORTEGA GET IN HEADED ', 'Featherweight champion Alexander Volkanovski and Brian Ortega will meet in the UFC 266 main event on Sept. 25 at T-Mobile Arena in Las Vegas', 'Featherweight champion Alexander Volkanovski and Brian Ortega will meet in the UFC 266 main event on Sept. 25 at T-Mobile Arena in Las Vegas. The two were originally scheduled to fight in March, but the bout was postponed due to COVID-19 protocols.\r\n\r\nIn the meantime, the two coach opposite each other on the return of The Ultimate Fighter reality series. During the season, the animosity between the two has grown and came out at the end of an interview with ESPN. Check it out.\r\n\r\nConor Mcgregor ', 'Ortega will meet in the UFC 266 main event on Sept. 25 at T-Mobile Arena in Las Vegas'),
(30, 'SEAN O’MALLEY UNHAPPY WITH UFC MATCHMAKER SEAN SHE', 'Sean O’Malley is not too happy with UFC matchmaker Sean Shel', 'don’t even know if I’m supposed to say this. I was talking to my manager and he was talking to Sean Shelby and Sean Shelby was mad at me,” O’Malley said. “Dude, I don’t want to fight in New York. It’s far. The taxes are ridiculous, and Tim has no no-gi or no, ADCC trials that weekend. And he told me that before I even potentially had a fight. So that’s his thing and I’m not gonna say ‘No, I have a fight we’re doing it.” Especially when I can fight a month later in Vegas', 'Sean Shelby was just like mad and [said] ‘Fine go hang out with 6ix9ine,’ and just acting like a f—–g tool, dude'),
(31, 'CONOR MCGREGOR UFC GOLD PRIZM CARD SELLS AT AUCTION FOR $', 'Over the weekend, a Conor McGregor UFC Gold Prism trading card sold for a record $27,060 at an auction from Goldin, a marketplace for trading cards, ', 'Over the weekend, a Conor McGregor UFC Gold Prism trading card sold for a record $27,060 at an auction from Goldin, a marketplace for trading cards, collectibles and memorabilia. The auction featured more than 3,700 rare, vintage and modern collectible items.\r\n\r\nThe price tag set the record for a UFC trading card sold at auction. McGregor is a former two-division UFC champion. He recently suffered a TKO loss to Dustin Poirier in their trilogy bout at UFC 264 in April after suffering a broken leg in the closing seconds of the opening', 'the weekend, a Conor McGregor UFC Gold Prism trad');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'Djdj', 'jdjdj@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4'),
(2, 'Spike_', 'predatora079@gmail.com', 'eec582628e4be2232fe88127090e5da2'),
(3, 'Pawan chu', 'jdjdhshsj@gmail.com', '900150983cd24fb0d6963f7d28e17f72'),
(4, 'Spike_', 'afityaj@gmail.com', '76d80224611fc919a5d54f0ff9fba446'),
(5, 'pri', 'a@gmail.com', 'f970e2767d0cfe75876ea857f92e319b'),
(6, 'a', 'as@gmail.com', '0cc175b9c0f1b6a831c399e269772661'),
(7, 'p', 'p@gmail.com', '83878c91171338902e0fe0fb97a8c47a'),
(8, 'rohit', 'ro@gmail.com', '0cc175b9c0f1b6a831c399e269772661'),
(9, 'Venus', 'v@gmail.com', '9e3669d19b675bd57058fd4664205d2a'),
(10, 'Rydudhrhf', 'po@gmail.com', 'f6122c971aeb03476bf01623b09ddfd4'),
(11, 'pd', 'poo@gmail.com', '83878c91171338902e0fe0fb97a8c47a'),
(12, 'primo', 'primo@gmail.com', '25c8fd756b4871e9295440291f1b22fe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
