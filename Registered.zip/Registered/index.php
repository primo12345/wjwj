<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nav</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     
  <style>
    
    header {
      background : url("img/C2.jpg");
      background-size: cover;
      background-position: center;
      min-height:1000px;
      
    }
    @media screen and (max-width:670px){
      header {
        min-height:500px;
      }
    }
  </style>
</head>

<body>
  
  <!--Nav-->
  <nav class="nav-wrapper white">
    <div class="container">
      <a href="#" class="brand-logo black-text">UFC</a>
      <a href="#" class="sidenav-trigger" data-target="mobile-links">
        <i class="material-icons black-text">menu</i></i>
      </a>
    </div>
  </nav>
  <ul class="sidenav" id="mobile-links">
    <li><a href="#"><h5>Home</h5></a></li>
    <li><a href=""><h5>News</h5></a></li>
    <li><a href="rankings.php"><h5>Rankings</h5></a></li>
    <li><a href="Reg.php"><h5>Sign-Up</h5></a></li>
  </ul>
  
  <header>
  </header>
  <div class="center-align white"><h3>WATCH <br>EMBEDDED</h3>
    <a class="white waves-effect waves-light btn-large black-text">WATCH</a>
  </div>
  
  
  
   <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/k2.jpg">
          </div>
          <div class="card-content">
            <span class="card-title">
              Covid Good Father Evil ?
            </span>
            <p>
             “When he talked about this, only evil can talk about your father, wife, kids, religion,” Nurmagomedov said. “
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/j2.jpg">
          </div>
          <div class="card-content">
            <span class="card-title">
              Doing What he does Best
            </span>
            <p>
             UFC LHW champion Jon Jones was arrested on DUI and deadly weapon charges once again 
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/dana.jpeg">
          </div>
          <div class="card-content">
            <span class="card-title">
              This is not a career
            </span>
            <p>
             “I’ve been hearing that bullshit forever. They are all full of shit. How many, what’s he making?
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/l1.jpg">
          </div>
          <div class="card-content">
            <span class="card-title">
              Derick slams Francis
            </span>
            <p>
             “He Wanted To Go And Play in The Sand But We Have a Business to Run We have to Keep Moving "
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
    <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/n1.jpeg">
          </div>
          <div class="card-content">
            <span class="card-title">
             Nate Diaz Is Angry
            </span>
            <p>
              Conor McGregor, you're taking everything I worked for, mother f*cker. I'm gonna fight your f*cking ass
             
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  
    <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/cc.jpeg">
          </div>
          <div class="card-content">
            <span class="card-title">
              He’s a fake nice guy
            </span>
            <p>
             “Colby Covington wants ‘Louisiana swamp trash’ Dustin Poirier after Kamaru Usman title fight "
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>
     <div class="container">
    <div class="row">
      <div class="col s12 16">
        <div class="card">
          <div class="card-image">
            <img src="img/C1.jpg">
          </div>
          <div class="card-content">
            <span class="card-title">
              He's going out on a stretcher.
            </span>
            <p>
             Conor McGregor suffered a broken leg in another crushing defeat to Dustin Poirier at the T-Mobile Arena in Las Vegas
            </p>
          </div>
          <div class="card-action">
            <a href="#" >VIEW</a>
          </div>
        </div>
      </div>
    </div>
  </div>
   <footer class="page-footer grey darken-3">
   <div class="container">
     <div class="row">
       <div class="col s12 l6">
       <h5>Join Now</h5>
     <p>The Ultimate Fighting Championship is an American mixed martial arts promotion company based in Las Vegas,
      Nevada, which is owned and operated by Zuffa, LLC</p>
       </div>
       <div class="col s12 l6">
        <h5>Connect</h5>  
          <ul>
            <li><a href="#" class="grey-text text-lighten-3">Email</a></li>
            <li><a href="Instagram app · Installed
Web results
Conor McGregor Official (@thenotoriousmma) • Instagram ..."class="grey-text text-lighten-3">Instagram</a></li>
            <li><a href="https://instagram.com/thenotoriousmma?utm_medium=copy_link" class="grey-text text-lighten-3">Twitter</a></li>
          </ul>
       </div>
     </div>
   </div>
 </footer>
  
  
  
  
      
    
  
  
  
  
  
  
  
  
      
    
  
  
  
  
  
   
 
 
<script src="https://code.jquery.com/jquery-3.6.0.min.js">
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js">
</script>

<script>
  $(document).ready(function(){
     $('.sidenav').sidenav();
  })
</script>
</body>
</html>
