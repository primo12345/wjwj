<?php
    include "conf.php";
    error_reporting(0);
    session_start();
    if (isset($_POST['submit'])) {
	$title= $_POST['title'];
	$subtitle= $_POST['discription'];
	$body = $_POST['body'];
	$footer= $_POST['footer'];

	if ($title=$title) {
		$sql = "SELECT * FROM data WHERE title='$title'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO data (title , subtitle, page,footer)
					VALUES ('$title', '$subtitle', '$body','$footer')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('data enterd.')</script>";
				$title= "";
				$subtitle = "";


			} else {
				echo "<script>alert('bncd error agaya')</script>";
			}
		} else {
			echo "<script>alert('bass kar kitne baar dalega')</script>";
		}
		
	} else {
		echo "<script>alert('ajeb vhutyapa')</script>";
	}
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
      #MyForm{
       	display: none;
        width: 390px;
        border: 1px solid #ccc;
        padding: 14px;
        background: #ececec;
      }	
      
      textarea.txt1{
        width: 360px;
        height: 150px;
      }
   
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-size: 25px;
text-align: left;
}
th {
background-color: black;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}

    </style>
     
</head>

<body>
  <nav class="nav-wrapper white">
    <div class="container">
      <a href="#" class="brand-logo black-text">CREATE
      </a>
      <a href="#" class="sidenav-trigger" data-target="mobile-links">
        <i class="material-icons black-text">menu</i>
        </i>
      </a>
    </div>
  </nav>
  <ul class="sidenav" id="mobile-links">
    <li><a href="#"><h5>Edit Ranking</h5></a></li>
    <li><a href="#"><h5>Write Blogs</h5></a></li>
    <li><a href="#"><h5>Admin Manager</h5></a></li>
    <li><a href="primo1.php"><h5>Home</h5></a></li>
  </ul>
  
  <div class="center-align white"><h4>Write Stories</h4>
    <a class="black waves-effect waves-light btn-large " id ="Mybtn">Write
    </a>
  </div>
  <form id="MyForm" action="" method="post">
  	<label>TITLE</label>
  	
	<input type="text" name="title" placeholder="header"/><br>
	</input>
	
  	<label>DISCRIPTION</label>
  <textarea name="discription" rows="7" cols="45" placeholder="enter discription"></textarea>
  
  <label>BODY</label>
  <textarea class="txt1" name="body" rows="7" cols="45" placeholder="enter discription"></textarea>
  
  <label>FOOTER</label>
  <textarea name="footer" rows="7" cols="45" placeholder="enter footer"></textarea>
  
  
  <div class="center-align input-group">
				<button name="submit" class="black btn">Enter </button>
 </div>  
 </form>
 
 
   <div class="center-align white"><h4>View Table</h4>
    <a class="black waves-effect waves-light btn-large " id ="MybtnT">VIEW
    </a>
  </div>
  
  
 
 
 <table id="MyTable" action="">
<tr>
<th>Id</th>
<th>Title</th>
<th>Subtitle</th>
</tr>
<?php
include "conf.php";

$sql = "SELECT id,title , subtitle FROM data";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["id"]. "</td><td>" . $row["title"] . "</td><td>"
. $row["subtitle"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>



   <div class="center-align white"><h4>View Users</h4>
    <a class="black waves-effect waves-light btn-large " id ="MybtnT1">VIEW
    </a>
  </div>
  


 <table id="MyTable02" action="">
<tr>
<th>Id</th>
<th>Name</th>
<th>Email</th>
</tr>
<?php
include "conf.php";

$sql = "SELECT id,username, email FROM users";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["id"]. "</td><td>" . $row["username"] . "</td><td>"
. $row["email"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>


 
  
  
      
   
  <script src="https://code.jquery.com/jquery-3.6.0.min.js">
</script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js">
  </script>
  <script>
      $(document).ready(function(){
   	$('#MybtnT').click(function(){
  		  $('#MyTable').toggle(500);
      });
    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js">
  </script>
  <script>
      $(document).ready(function(){
   	$('#MybtnT1').click(function(){
  		  $('#MyTable02').toggle(500);
      });
    });
</script>




  <script>
    $(document).ready(function(){
   	$('#Mybtn').click(function(){
  		  $('#MyForm').toggle(500);
      });
    });
    
        
  </script>
  <script>
    $(document).ready(function(){
     $('.sidenav').sidenav();
    })
  </script>
</body>

</html>