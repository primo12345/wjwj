<?php 

include 'conf.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: Reg.php");
}

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);

	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
		if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users (username, email, password)
					VALUES ('$username', '$email', '$password')";
			$result = mysqli_query($conn, $sql);
			if ($result) {
				echo "<script>alert('Wow! User Registration Completed.')</script>";
				$username = "";
				$email = "";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
			} else {
				echo "<script>alert('Woops! Something Wrong Went.')</script>";
			}
		} else {
			echo "<script>alert('email already exists')</script>";
		}
		
	} else {
		echo "<script>alert('Password Not Matched.')</script>";
	}
}

?>
<!DOCTYPE html>
<html>
  <head>
      <meta name="viewport" content="width=device-width,initial-scale=1.0">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
     <style>
       body{
         background-color: white;
       }
     
       .progress{
         width:50%;
         margin:0 auto;
         margin-top:20%;
       }
       
       @media only screen and (max-width:924px){
            .progress{
               width:70%;
               margin:0 auto;
               margin-top:60%;
             }
       }
    
     </style>
  </head>
  
  <body>
    
     <div id="flayer">
          <div id="slayer">
    
    <div class="container" id="content">
        
       
        <div class="row">
          <div class="col l3 m3 s12"></div>
          <div class="col l6 m6 s12">
            <form action="" method="POST">
                 <div class="card-panel z-depth-5">
                  <h5 class="center">Register</h5>
                
                   <div class="input-field">
                    <i class="material-icons prefix">account_circle</i>
                    <input type="text" placeholder="Name" name="username" name="username" value="<?php echo $username; ?>" required>

                    <label>Enter username</label>
                  </div>
                  
                   <div class="input-field">
                    <i class="material-icons prefix">email</i>
                    	<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
	
                    <label>Enter email</label>
                  </div>
                  
                   <div class="input-field">
                    <i class="material-icons prefix">lock</i>
                    <input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
          
                    <label>Enter password</label>
                  </div>
                  
                    
                   <div class="input-field">
                    <i class="material-icons prefix">vpn_key</i>
                    <input type="password" placeholder="Confirm Password" name="cpassword" value="<?php echo $_POST['cpassword']; ?>" required>

                    <label>Confirm password</label>
                  </div>
                 <div class="center-align input-group">
				<button name="submit" class="black btn">Register</button>
			</div>
			<p class="login-register-text">Have an account? <a href="login.php">Login Here</a>.</p>
	                
                  <div class="clearfix"></div>
               </div>
            </form>
            
          </div>
            <div class="col l3 m3 s12"></div>
      
          
          
        </div>
    </div>
 </div>

    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
    
      const login = document.querySelectorAll(".modal");
      M.Modal.init(login,{
        opacity:0.7,
        dismissible:false
      });
      
      document.querySelector("#content").style.display="none";
      document.querySelector("#flayer").classList.add("progress");
      document.querySelector("#slayer").classList.add("indeterminate");
      
      setTimeout(function(){
          document.querySelector("#flayer").classList.remove("progress");
          document.querySelector("#slayer").classList.remove("indeterminate");
          document.querySelector("#content").style.display="block";
      },3000)
    </script>
  </body>
</html>